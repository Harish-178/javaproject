package com.qn.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Car {
	private String username;
	private String carmodel;
	private String cartype;
	private String carregnumber;
	private String servicerequest;
	private String servicestatus;
	private Connection con;
	public Car(String username, String carmodel, String cartype, String carregnumber, String servicerequest,
			String servicestatus) {
		super();
		this.username = username;
		this.carmodel = carmodel;
		this.cartype = cartype;
		this.carregnumber = carregnumber;
		this.servicerequest = servicerequest;
		this.servicestatus = servicestatus;
	}
	public Car() {
		super();
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCarmodel() {
		return carmodel;
	}
	public void setCarmodel(String carmodel) {
		this.carmodel = carmodel;
	}
	public String getCartype() {
		return cartype;
	}
	public void setCartype(String cartype) {
		this.cartype = cartype;
	}
	public String getCarregnumber() {
		return carregnumber;
	}
	public void setCarregnumber(String carregnumber) {
		this.carregnumber = carregnumber;
	}
	public String getServicerequest() {
		return servicerequest;
	}
	public void setServicerequest(String servicerequest) {
		this.servicerequest = servicerequest;
	}
	public String getServicestatus() {
		return servicestatus;
	}
	public void setServicestatus(String servicestatus) {
		this.servicestatus = servicestatus;
	}
	@Override
	public String toString() {
		return "Car [username=" + username + ", carmodel=" + carmodel + ", cartype=" + cartype + ", carregnumber="
				+ carregnumber + ", servicerequest=" + servicerequest + ", servicestatus=" + servicestatus + "]";
	}

	{
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system","root","harii@17");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public int carDetails() {
		try {
			String s="insert into car values(?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(s);
		pstmt.setString(1, username);
		pstmt.setString(2, carmodel);
		pstmt.setString(3, cartype);
		pstmt.setString(4, carregnumber);
		pstmt.setString(5,"NA");
		pstmt.setString(6,"NA");
		
		int rows=pstmt.executeUpdate();
		return rows;
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
